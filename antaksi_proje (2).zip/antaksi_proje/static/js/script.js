document.addEventListener('DOMContentLoaded', function() {
    console.log('Sayfa yüklendi');
    
    // API'den veri çekme örneği
    fetch('/api/data')
        .then(response => response.json())
        .then(data => {
            console.log('API verisi:', data);
        });
    
    // Buton tıklama olayları
    document.querySelectorAll('.btn').forEach(button => {
        button.addEventListener('click', function() {
            alert(this.textContent + ' butonuna tıklandı');
        });
    });
});