﻿from flask import render_template
from flask_login import login_required, current_user
from app.driver import bp

@bp.route('/dashboard')
@login_required
def dashboard():
    if current_user.user_type != 'driver':
        return 'Bu sayfaya erişim izniniz yok.', 403
    return render_template('driver/dashboard.html')
