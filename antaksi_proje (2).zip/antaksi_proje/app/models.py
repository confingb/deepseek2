﻿from datetime import datetime
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from app import db, login_manager

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(128))
    name = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    user_type = db.Column(db.String(20), nullable=False, default='passenger')  # 'passenger' or 'driver'
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Araç bilgileri (sürücü için)
    vehicle_model = db.Column(db.String(50))
    vehicle_plate = db.Column(db.String(20))
    vehicle_color = db.Column(db.String(20))
    
    # Konum bilgileri (gerçek zamanlı)
    current_lat = db.Column(db.Float)
    current_lng = db.Column(db.Float)
    is_available = db.Column(db.Boolean, default=False)  # Sürücü müsait mi?
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def __repr__(self):
        return f'<User {self.email}>'

class Ride(db.Model):
    __tablename__ = 'rides'
    
    id = db.Column(db.Integer, primary_key=True)
    passenger_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    driver_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    
    pickup_address = db.Column(db.String(200), nullable=False)
    pickup_lat = db.Column(db.Float)
    pickup_lng = db.Column(db.Float)
    
    dropoff_address = db.Column(db.String(200), nullable=False)
    dropoff_lat = db.Column(db.Float)
    dropoff_lng = db.Column(db.Float)
    
    status = db.Column(db.String(20), default='requested')  # requested, accepted, in_progress, completed, cancelled
    fare = db.Column(db.Float)
    distance = db.Column(db.Float)  # km cinsinden
    estimated_time = db.Column(db.Integer)  # dakika cinsinden
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    accepted_at = db.Column(db.DateTime)
    started_at = db.Column(db.DateTime)
    completed_at = db.Column(db.DateTime)
    
    # İlişkiler
    passenger = db.relationship('User', foreign_keys=[passenger_id], backref='passenger_rides')
    driver = db.relationship('User', foreign_keys=[driver_id], backref='driver_rides')

@login_manager.user_loader
def load_user(id):
    return User.query.get(int(id))
