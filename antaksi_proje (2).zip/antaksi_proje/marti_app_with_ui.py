"""
ANTARTAXI - Ana Uygulama Başlatıcı

Bu dosya, tüm API ve frontend bileşenlerini bir araya getirir.
Web arayüzü, API endpoints ve WebSocket desteği sağlar.
"""

import os
import sys
from pathlib import Path

# Proje kök dizinini ekle
sys.path.insert(0, str(Path(__file__).parent))

from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

# API modülünü import et
import antaksi_secure_api as api

# Uygulama oluştur
app = FastAPI(
    title="ANTARTAXI Platform",
    description="Gelişmiş Taksi/Ulaşım Çözümü",
    version="2.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    openapi_url="/api/openapi.json"
)

# CORS ayarları
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Production'da spesifik domain'ler kullanın
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# API endpoints'ini mount et
app.mount("/api", api.app)

# Static dosyalar
static_dir = Path(__file__).parent / "static"
static_dir.mkdir(exist_ok=True)

app.mount("/static", StaticFiles(directory=static_dir), name="static")

# WebSocket connections
active_connections = {}

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    connection_id = id(websocket)
    active_connections[connection_id] = websocket
    
    try:
        while True:
            data = await websocket.receive_text()
            # Broadcast to all connections
            for conn in active_connections.values():
                await conn.send_text(f"Message: {data}")
    except WebSocketDisconnect:
        del active_connections[connection_id]

# Ana sayfa
@app.get("/", response_class=HTMLResponse)
async def home():
    """Ana sayfa."""
    index_path = static_dir / "index.html"
    if index_path.exists():
        return HTMLResponse(content=index_path.read_text(encoding="utf-8"))
    
    # Varsayılan HTML
    html = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>ANTARTAXI</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                text-align: center;
                padding: 50px;
                background: linear-gradient(135deg, #00B4D8 0%, #FF6B35 100%);
                color: white;
            }
            .container {
                max-width: 800px;
                margin: 0 auto;
                background: rgba(255,255,255,0.1);
                padding: 40px;
                border-radius: 20px;
                backdrop-filter: blur(10px);
            }
            h1 {
                font-size: 3em;
                margin-bottom: 20px;
            }
            .links {
                display: flex;
                gap: 20px;
                justify-content: center;
                margin-top: 40px;
                flex-wrap: wrap;
            }
            .btn {
                display: inline-block;
                padding: 15px 30px;
                background: white;
                color: #00B4D8;
                text-decoration: none;
                border-radius: 30px;
                font-weight: bold;
                transition: transform 0.3s;
            }
            .btn:hover {
                transform: translateY(-5px);
                box-shadow: 0 10px 20px rgba(0,0,0,0.2);
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🚕 ANTARTAXI</h1>
            <p style="font-size: 1.2em; margin-bottom: 30px;">
                Akıllı Ulaşım Platformu - v2.0
            </p>
            
            <div class="links">
                <a href="/antaksi" class="btn">🌐 Ana Arayüz</a>
                <a href="/api/docs" class="btn">📚 API Dokümantasyonu</a>
                <a href="/api/redoc" class="btn">🔍 API ReDoc</a>
            </div>
            
            <div style="margin-top: 50px; text-align: left; background: rgba(255,255,255,0.1); padding: 20px; border-radius: 10px;">
                <h3>Hızlı Başlangıç:</h3>
                <ul>
                    <li>Yolcu olarak kaydol: <code>/antaksi/register</code></li>
                    <li>Sürücü başvurusu: <code>/antaksi/register?role=driver</code></li>
                    <li>Yönetici paneli: <code>/antaksi/admin</code> (admin/Admin@123)</li>
                    <li>API test: <code>/api/docs</code></li>
                </ul>
            </div>
        </div>
    </body>
    </html>
    """
    return HTMLResponse(content=html)

# API health check
@app.get("/health")
async def health_check():
    """Sistem sağlık kontrolü."""
    return {
        "status": "healthy",
        "service": "antartaxi",
        "version": "2.0.0",
        "api": "/api",
        "docs": "/api/docs"
    }

# Frontend yönlendirmeleri
@app.get("/antaksi")
async def antaksi_home():
    """Antaksi ana sayfası."""
    return RedirectResponse(url="/")

@app.get("/antaksi/{page:path}")
async def antaksi_page(page: str):
    """Antaksi sayfaları."""
    html_file = static_dir / f"antaksi_{page}.html"
    
    if html_file.exists():
        return HTMLResponse(content=html_file.read_text(encoding="utf-8"))
    
    # Fallback to index
    index_file = static_dir / "index.html"
    if index_file.exists():
        return HTMLResponse(content=index_file.read_text(encoding="utf-8"))
    
    raise HTTPException(status_code=404, detail="Sayfa bulunamadı")

# Hata yönetimi
@app.exception_handler(404)
async def not_found(request, exc):
    """404 hatalarını yönet."""
    return JSONResponse(
        status_code=404,
        content={"error": "Sayfa bulunamadı", "path": request.url.path}
    )

@app.exception_handler(500)
async def server_error(request, exc):
    """500 hatalarını yönet."""
    return JSONResponse(
        status_code=500,
        content={"error": "Sunucu hatası", "detail": str(exc)}
    )

# Uygulama başlatma
@app.on_event("startup")
async def startup_event():
    """Uygulama başlangıç olayları."""
    print("\n" + "="*60)
    print("ANTARTAXI Platform v2.0")
    print("="*60)
    print(f"\n📊 API Dokümantasyonu: http://localhost:8000/api/docs")
    print(f"🌐 Web Arayüzü: http://localhost:8000")
    print(f"📱 Mobil Uyumlu: Evet")
    print(f"🔌 WebSocket: ws://localhost:8000/ws")
    print(f"💾 Veritabanı: {api.DB_PATH.name}")
    print("\n👤 Varsayılan Admin:")
    print("   Email: admin@antaksi.com")
    print("   Şifre: Admin@123")
    print("\n" + "="*60)

# Ana çalıştırma
if __name__ == "__main__":
    # Port ve host ayarları
    port = int(os.getenv("PORT", 8000))
    host = os.getenv("HOST", "0.0.0.0")
    
    # Uvicorn ile başlat
    uvicorn.run(
        "marti_app_with_ui:app",
        host=host,
        port=port,
        reload=True,
        log_level="info"
    )