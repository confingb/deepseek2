﻿from flask import Flask
app = Flask(__name__)

@app.route('/')
def hello():
    return '🚖 ANTAKSİ TEST - ÇALIŞIYOR!'

if __name__ == '__main__':
    print('TEST SUNUCUSU: http://127.0.0.1:5555')
    app.run(debug=True, port=5555)
