﻿from flask import Flask, render_template_string

app = Flask(__name__)
app.config['SECRET_KEY'] = 'antaksi-test-2024'

HOME_PAGE = '''
<!DOCTYPE html>
<html>
<head>
    <title>🚖 Antaksi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root { --primary: #0d6efd; --gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
        body { background: var(--gradient); min-height: 100vh; font-family: 'Segoe UI', sans-serif; }
        .app-card { background: white; border-radius: 25px; padding: 40px; box-shadow: 0 20px 60px rgba(0,0,0,0.3); }
        .btn-app { background: var(--gradient); color: white; border: none; padding: 15px 30px; font-size: 18px; border-radius: 12px; }
        .feature-icon { font-size: 40px; color: var(--primary); }
    </style>
</head>
<body class="d-flex align-items-center">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6">
                <div class="app-card">
                    <!-- Logo & Title -->
                    <div class="text-center mb-5">
                        <div class="display-1">🚖</div>
                        <h1 class="fw-bold" style="background: var(--gradient); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                            Antaksi
                        </h1>
                        <p class="text-muted lead">Profesyonel Taksi Uygulaması</p>
                    </div>
                    
                    <!-- Buttons -->
                    <div class="text-center mb-5">
                        <a href="/login" class="btn-app btn-lg me-3">
                            <i class="bi bi-box-arrow-in-right me-2"></i>Giriş Yap
                        </a>
                        <a href="/register" class="btn btn-outline-primary btn-lg px-4">
                            <i class="bi bi-person-plus me-2"></i>Kayıt Ol
                        </a>
                    </div>
                    
                    <!-- Features -->
                    <div class="row text-center mt-5">
                        <div class="col-md-3 mb-4">
                            <i class="bi bi-lightning-charge feature-icon"></i>
                            <h5 class="mt-2">Hızlı</h5>
                            <small class="text-muted">60 saniyede taksi</small>
                        </div>
                        <div class="col-md-3 mb-4">
                            <i class="bi bi-shield-check feature-icon"></i>
                            <h5 class="mt-2">Güvenli</h5>
                            <small class="text-muted">Onaylı sürücüler</small>
                        </div>
                        <div class="col-md-3 mb-4">
                            <i class="bi bi-phone feature-icon"></i>
                            <h5 class="mt-2">Mobil</h5>
                            <small class="text-muted">Tüm cihazlarda</small>
                        </div>
                        <div class="col-md-3 mb-4">
                            <i class="bi bi-cash-coin feature-icon"></i>
                            <h5 class="mt-2">Ekonomik</h5>
                            <small class="text-muted">Uygun fiyatlar</small>
                        </div>
                    </div>
                    
                    <!-- Mobile QR -->
                    <div class="text-center mt-5 pt-4 border-top">
                        <p class="text-muted">
                            <i class="bi bi-qr-code me-2"></i>
                            Mobil uyumlu PWA - Telefondan da açılabilir
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
'''

LOGIN_PAGE = '''
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="app-card">
                <h2 class="text-center mb-4"><i class="bi bi-box-arrow-in-right"></i> Giriş Yap</h2>
                <form action="/login" method="POST">
                    <div class="mb-3">
                        <label class="form-label">Email Adresi</label>
                        <input type="email" class="form-control form-control-lg" placeholder="ornek@email.com" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Şifre</label>
                        <input type="password" class="form-control form-control-lg" placeholder="••••••••" required>
                    </div>
                    <button type="submit" class="btn-app w-100 py-3">
                        <i class="bi bi-key me-2"></i>Giriş Yap
                    </button>
                </form>
                <div class="text-center mt-4">
                    <p>Test için: <strong>test@antaksi.com</strong> / <strong>test123</strong></p>
                    <a href="/" class="text-decoration-none">← Ana Sayfaya Dön</a>
                </div>
            </div>
        </div>
    </div>
</div>
'''

REGISTER_PAGE = '''
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="app-card">
                <h2 class="text-center mb-4"><i class="bi bi-person-plus"></i> Kayıt Ol</h2>
                <div class="alert alert-info">
                    <h5><i class="bi bi-info-circle"></i> Kayıt Sistemi Hazırlanıyor</h5>
                    <p>Profesyonel kayıt sistemi yakında aktif olacak. Şu anda test modundayız.</p>
                </div>
                <div class="text-center mt-4">
                    <a href="/login" class="btn btn-primary">
                        <i class="bi bi-box-arrow-in-right me-2"></i>Giriş Sayfasına Git
                    </a>
                    <a href="/" class="btn btn-outline-secondary ms-2">
                        <i class="bi bi-house me-2"></i>Ana Sayfa
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
'''

@app.route('/')
def home():
    return render_template_string(HOME_PAGE)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        return '''
        <div class="container mt-5">
            <div class="row justify-content-center">
                <div class="col-md-5">
                    <div class="app-card text-center">
                        <div class="display-1 text-success">✅</div>
                        <h2 class="mt-3">Giriş Başarılı!</h2>
                        <p class="lead">Hoş geldiniz, Test Kullanıcı!</p>
                        <div class="mt-4">
                            <a href="/" class="btn-app">
                                <i class="bi bi-house me-2"></i>Ana Sayfaya Dön
                            </a>
                        </div>
                        <div class="mt-4 text-start">
                            <h5>Yapabilecekleriniz:</h5>
                            <ul>
                                <li>Taksi çağırma (yakında)</li>
                                <li>Sürücü olma (yakında)</li>
                                <li>Geçmiş sürüşler (yakında)</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        '''
    return render_template_string(LOGIN_PAGE)

@app.route('/register')
def register():
    return render_template_string(REGISTER_PAGE)

if __name__ == '__main__':
    print("="*60)
    print("🚖 ANTAKSİ - PROFESYONEL TAKSİ UYGULAMASI")
    print("🌐 Adres: http://127.0.0.1:5000")
    print("📱 Telefon: Aynı WiFi'de http://[IP_ADRESIN]:5000")
    print("💡 Test Giriş: test@antaksi.com / test123")
    print("="*60)
    app.run(debug=True, host='0.0.0.0', port=5000, use_reloader=False)
