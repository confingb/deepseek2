﻿from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from werkzeug.security import generate_password_hash
from datetime import datetime

app = Flask(__name__)
app.config['SECRET_KEY'] = 'antaksi-users-2024'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///antaksi_users.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
login_manager = LoginManager(app)

# User Model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True)
    password_hash = db.Column(db.String(128))
    name = db.Column(db.String(100))
    phone = db.Column(db.String(20))
    user_type = db.Column(db.String(20))  # passenger, driver, admin
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

# Kullanıcıları ekle
with app.app_context():
    # Database'i oluştur
    db.create_all()
    
    # Kullanıcı listesi
    users = [
        # Yolcu
        {'email': 'emre@antaksi.com', 'password': 'emre123', 'name': 'Emre Yolcu', 'phone': '05551112233', 'user_type': 'passenger'},
        
        # Sürücü
        {'email': 'emre321@antaksi.com', 'password': 'emre321', 'name': 'Emre Sürücü', 'phone': '05554445566', 'user_type': 'driver'},
        
        # Admin
        {'email': 'admin@antaksi.com', 'password': '123emre', 'name': 'Admin Emre', 'phone': '05557778899', 'user_type': 'admin'},
        
        # Test Kullanıcıları
        {'email': 'ahmet@antaksi.com', 'password': 'ahmet123', 'name': 'Ahmet Yılmaz', 'phone': '05551234567', 'user_type': 'passenger'},
        {'email': 'mehmet@antaksi.com', 'password': 'mehmet123', 'name': 'Mehmet Demir', 'phone': '05552345678', 'user_type': 'driver'},
        {'email': 'ayse@antaksi.com', 'password': 'ayse123', 'name': 'Ayşe Kaya', 'phone': '05553456789', 'user_type': 'passenger'},
        {'email': 'fatma@antaksi.com', 'password': 'fatma123', 'name': 'Fatma Şahin', 'phone': '05554567890', 'user_type': 'driver'},
    ]
    
    added_count = 0
    for user_data in users:
        # Kullanıcı var mı kontrol et
        existing = User.query.filter_by(email=user_data['email']).first()
        if not existing:
            user = User(
                email=user_data['email'],
                name=user_data['name'],
                phone=user_data['phone'],
                user_type=user_data['user_type']
            )
            user.set_password(user_data['password'])
            db.session.add(user)
            added_count += 1
    
    db.session.commit()
    
    print("="*60)
    print("✅ KULLANICILAR EKLENDİ!")
    print("="*60)
    print(f"Toplam {added_count} yeni kullanıcı eklendi.")
    print("\n📋 KULLANICI LİSTESİ:")
    print("-"*40)
    
    all_users = User.query.all()
    for user in all_users:
        print(f"👤 {user.name}")
        print(f"   📧 {user.email}")
        print(f"   🔑 Şifre: {[u['password'] for u in users if u['email'] == user.email][0]}")
        print(f"   📞 {user.phone}")
        print(f"   🏷️  Tip: {user.user_type}")
        print(f"   🆔 ID: {user.id}")
        print("-"*40)
    
    print("\n🚀 GİRİŞ BİLGİLERİ:")
    print("1. YOLCU: emre@antaksi.com / emre123")
    print("2. SÜRÜCÜ: emre321@antaksi.com / emre321")
    print("3. ADMIN: admin@antaksi.com / 123emre")
    print("="*60)
